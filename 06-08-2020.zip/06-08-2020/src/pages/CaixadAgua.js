import React from 'react';
import CardListAgua from '../components/CardListAgua'

const CaixadAgua = ({ }) => {

    
    return (
        <div className="page" >
            <CardListAgua />
        </div>
    )
}
export default CaixadAgua;