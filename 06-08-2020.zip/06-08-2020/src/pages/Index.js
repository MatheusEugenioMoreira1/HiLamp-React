import React from 'react';
import IndexCardList from '../components/IndexCardList'

const Index = ({ }) => {

    
    return (
        <div className="page" >
            <IndexCardList />
        </div>
    )
}
export default Index;