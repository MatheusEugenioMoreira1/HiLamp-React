import React from 'react';
import CardListG from '../components/CardListG'


const Garagem = () => {
    return (
        <div className="page" >
            <CardListG />
        </div>
    )
}

export default Garagem;