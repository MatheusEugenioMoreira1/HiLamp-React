import React from 'react';
import IndexCardList from '../components/IndexCardList'
import bg from '../logo.svg'
const Index = ({ }) => {

    const style = {
        backgroundImage: 'url("' + bg + '")',
    };
    
    return (
        <div className="page" style={style}>
            <IndexCardList />
        </div>
    )
}
export default Index;