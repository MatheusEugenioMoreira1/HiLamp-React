import React from 'react';
import CardList1Andar from '../components/CardList1Andar'


const Primeirondar = () => {
    return (
        <div className="page" >
            <CardList1Andar/>
        </div>
    )
}

export default Primeirondar;